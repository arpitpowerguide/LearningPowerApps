﻿using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerAppsBook.Case.CheckRefundRequest
{
    public class CheckRefundRequestCount : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // Obtain the IOrganizationService instance which you will need for  
            // web service calls.  
            IOrganizationServiceFactory serviceFactory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);


            // The InputParameters collection contains all the data passed in the message request.
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                // Obtain the target entity from the input parameters.
                Entity currentCaseRecord = (Entity)context.InputParameters["Target"];

                int caseStatus = currentCaseRecord.GetAttributeValue<OptionSetValue>("arp_casestatus").Value;

                if (currentCaseRecord.LogicalName == "arp_case" && caseStatus == 750870002)
                {
                    string fetchOpenRefundRequests = @"  
                            <fetch version='1.0' mapping='logical' savedqueryid='11ede493-b00e-4fd4-89e7-592baaa46cc3' no-lock='false' distinct='true' >
                              <entity name='arp_case' >
                                <attribute name='statecode' />
                                <attribute name='arp_name' />
                                <attribute name='createdon' />
                                <order attribute='arp_name' descending='false' />
                                <attribute name='arp_casestatus' />
                                <attribute name='arp_casenumber' />
                                <attribute name='arp_caseid' />
                                <filter type='and' >
                                  <condition attribute='arp_parentcase' operator='eq' value='{" + currentCaseRecord.Id + @"}' uitype='arp_case' />
                                  <condition attribute='arp_casestatus' operator='in' >
                                    <value>750870000</value>
                                    <value>750870001</value>
                                    <value>750870006</value>
                                    <value>750870005</value>
                                  </condition>
                                </filter>
                              </entity>
                            </fetch>";

                    EntityCollection result = service.RetrieveMultiple(new FetchExpression(fetchOpenRefundRequests));

                    int resultCount = result.Entities.Count;

                    if (resultCount > 0)
                    {
                        throw new InvalidPluginExecutionException("This case cannot be closed because a refund request is still being processed");
                    }

                }
            }

        }
    }
}
