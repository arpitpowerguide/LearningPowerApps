﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomAPIPlugin
{
    public class PerformOperation : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the tracing service
            ITracingService tracingService =
            (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            // Obtain the execution context from the service provider.  
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));
            if (context.MessageName.Equals("arp_PowerAppsCustomAPI") && context.Stage.Equals(30))
            {
                try
                {
                    string input = (string)context.InputParameters["PowerAppsInput"];
                    if (!string.IsNullOrEmpty(input))
                    {
                        //Simply reversing the characters of the string
                        context.OutputParameters["PowerAppsOutput"] = "Your Input Parameter is: "+input;
                    }
                }
                catch (Exception ex)
                {
                    tracingService.Trace("arp_PowerAppsCustomAPI: {0}", ex.ToString());
                    throw new InvalidPluginExecutionException("An error occurred in arp_PowerAppsCustomAPI.", ex);
                }
            }
            else
            {
                tracingService.Trace("arp_PowerAppsCustomAPI plug-in is not associated with the expected message or is not registered for the main operation.");
            }
        }
    }
}
